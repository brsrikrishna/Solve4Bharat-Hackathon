import cv2
import numpy as np
import struct
import pickle
import socket
import sys

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
s.connect(('192.168.31.88',8089))
CLASSES = ["Person"]

COLORS = np.random.uniform(0, 255, size=(len(CLASSES), 3))

net = cv2.dnn.readNetFromCaffe(r'C:\Users\ASUS\Desktop\human_detection\MobileNetSSD_deploy.prototxt.txt',r'C:\Users\ASUS\Desktop\human_detection\MobileNetSSD_deploy.caffemodel')

key = ' '
image = cv2.VideoCapture(1)
while key != 113 :
    _,image_ocv = image.read()
    (h, w) = image_ocv.shape[:2]
    blob = cv2.dnn.blobFromImage(cv2.resize(image_ocv, (300, 300)), 0.007843, (300, 300), 127.5)
    net.setInput(blob)
    detections = net.forward()
    global l
    l = []
    for i in np.arange(0, detections.shape[2]):
        idx = int(detections[0, 0, i, 1])
        box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
        (startX, startY, endX, endY) = box.astype("int")
        if(abs(endX-startX)<150 and abs(endX-startX)>50):
            if(abs(endY-startY)<150 and abs(endY-startY)>50):
                cv2.rectangle(image_ocv, (startX, startY), (endX, endY),COLORS[0], 2)
                param2 = l.append([startX,startY,endX,endY])
                data = pickle.dumps(image_ocv,protocol=2)
                message_size = struct.pack("L", len(data))
                s.sendall(message_size + data)
        #cv2.imshow("Image", image_ocv)
    key = cv2.waitKey(1)
cv2.destroyAllWindows()
